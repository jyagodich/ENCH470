# ENCH470-FA2020

Learn how to use GitHub for final projects in ENCH 470!
Most of what you need to learn can be found here: https://guides.github.com/activities/hello-world/
